const ROUTES = {
  HOME: "/",
  CHAT: "/chat",
};

export { ROUTES };
