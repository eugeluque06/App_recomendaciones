# tnt2023-react-native
App a desarrollar para la cursada de Taller de Nuevas Tecnologías 2023 de la Universidad Nacional de Tierra del Fuego
